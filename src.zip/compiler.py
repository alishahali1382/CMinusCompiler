# 400109905 - Ali Shahali
# 400109287 - Arefe Boushehrian

from scanner import Scanner

Scanner().tokenize()
